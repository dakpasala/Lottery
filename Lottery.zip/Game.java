import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;

public class Game{
    private ArrayList<Integer> wins = new ArrayList<Integer>();
    Random random = new Random();
    public Game(){}
    public ArrayList<Integer> getWins(){
        return new ArrayList<Integer>(this.wins);}
    public void winnings(){
        wins.clear();
        while (wins.size() < 5) {
            int val = random.nextInt(43);
            int size = 0;
            for (int i=0; i<wins.size(); i++) {
                if (wins.get(i) != val) {
                    size++;
                }
            }
            if (size == wins.size()) {
                wins.add(val);
            }
        }
    }
    public int matches(ArrayList<Integer> a){
        int count = 0;
        for (int i=0; i<a.size(); i++) {
           if (wins.contains(a.get(i))) {
               count ++;
            }
        }
        return count;
    }

    public float monetary(int matches){
        if (matches == 2) {
            return 0;
        }
        else if (matches == 3) {
            return 10.86f;
        }
        else if (matches == 4) {
            return 197.53f;
        }
        else if (matches == 5) {
            return 212534.83f;
        }
        return -1;
    }
}