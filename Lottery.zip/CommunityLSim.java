import java.util.*;

public final class CommunityLSim {
   //instance variables
  private ArrayList<Player> players;
  int numPeeps;
  Random random = new Random();
  //TODO: you will need to add more instance variables
  ArrayList<Integer> lst = new ArrayList<Integer>();
  private ArrayList<Integer> rando = new ArrayList<>();
  //Constructor
  public CommunityLSim( int numP) {
	  numPeeps = numP;
	  //create the players
	  players = new ArrayList<Player>();

	  //generate a community of 30
	  for (int i = 0; i < numPeeps; i++) {
		  if (i < numPeeps/2.0)
			  players.add(new Player(PlayerKind.POORLY_PAID, (float)(99+Math.random())));
		  else
			  players.add(new Player(PlayerKind.WELL_PAID, (float)(100.1+Math.random())));
	  }

  }

	public ArrayList<Integer> getLst() {
	  return lst;
	}

	public int getSize() {
	  return numPeeps;
	}

	public Player getPlayer(int i) {
	  return players.get(i);
	}
	public float getRichest(){
		float max = -1;
		for (int i=0; i<players.size(); i++) {
			if (players.get(i).getMoney() > max) {
				max = players.get(i).getMoney();
			}
		}
		return max;
	}
	public float getWorst(){
		float min = Integer.MAX_VALUE;
		for (int i=0; i<players.size(); i++) {
			if (players.get(i).getMoney() < min) {
				min = players.get(i).getMoney();
			}
		}
		return min;
	}
   // TODO
   public void addPocketChange() {
	   for (int i=0; i<players.size(); i++) {
		   if (players.get(i).getKind() == PlayerKind.WELL_PAID ) {
			   players.get(i).addMoney(0.1f);
		   }
		   else if (players.get(i).getKind() == PlayerKind.POORLY_PAID) {
			   players.get(i).addMoney(0.03f);
		   }
	   }
   }

	public void reDoWhoPlays() {
		lst.clear();

		randomUniqIndx(((players.size() /2)*6)/10, 0, players.size()/2);

		lst.addAll(rando);

		randomUniqIndx(((players.size()/2)*4)/10, players.size()/2, players.size());

		lst.addAll(rando);
   }

	/*TODO generate some random indices for who might play the lottery
        in a given range of indices */
	public void randomUniqIndx(int numI, int startRange, int endRange) {
		 rando.clear();
		 while (rando.size() < numI){
			 rando.add(random.nextInt(endRange-startRange) + startRange);
		 }
	}
    public void giveScholarship() {
		int ran = random.nextInt(10);
		if (ran > 2){
			players.get(random.nextInt(players.size()/2) + players.size()/2).addMoney(1);
		}
		else {
			players.get(random.nextInt(players.size()/2)).addMoney(1);}
	}

	public void simulateYears(int numYears) {
		/*now simulate lottery play for some years */
		for (int year=0; year < numYears; year++) {
			reDoWhoPlays();
			addPocketChange();
			// TODO: add code so that each member of the community who plays, plays
			//right now just everyone updates their list of funds each year

			Game c= new Game();
			c.winnings();
            c.getWins();
			for (int index: lst) {
				players.get(index).playRandom();
				int matches = c.matches(players.get(index).getNums());
				players.get(index).addMoney(c.monetary(matches));

				if(matches < 2){
					giveScholarship();
				}

			}
			for (Player p : players) {
				p.updateMoneyEachYear();
			}
			System.out.println("After this year has happened: " + year);
			System.out.printf("The richest person in this year %.5f\n", getRichest());
			System.out.printf("The poorest person in this year: %.5f\n", getWorst());
		}
	}


}